# Changelog

Versions use MAJOR.MINOR.PATCH. The application version is defined once in
`frontends/cli.py`; Debian packaging revisions use a separate `-N` suffix.
API schema versions are independent of release versions.

## 1.1.0 — 2026-10-11

- The GPU of any host is read from the standard DRM class and the NPU from the accel class, with one
  short reader per driver: `i915` reports the share of the window the GPU was not idle with its clock
  and ceiling, `amdgpu` the busy share it publishes itself, and `intel_vpu` the share the NPU worked.
  A board module is still asked first, so a Jetson keeps its own source. A card whose driver publishes
  no load is reported by name without numbers, and a host without one says `not_detected`.
- `/api/stats` gains an `npu` object and a `npu` collector entry beside `gpu`; `gpu/usage` and
  `npu/usage` join the history. `schema_version` stays 1 and every existing key is unchanged, so an
  older client ignores the additions. A GPU without a load reading is now possible, and both viewers
  handle it.
- The web page's Recent history draws every series the endpoint gives it, instead of the first twelve
  with a dropdown for the rest. A row of buttons names the kinds of series the view holds so a viewer
  can take one out, and each kind gets its own labelled section.
- `platmon` live view shows one view at a time, the same six the web page has as tabs: Overview,
  Resources, Network, Storage, Temp & power and System. `1`-`6`, Tab and the arrow keys switch them,
  `--view` picks the first one, and a tab bar in the header names them. Switching makes no request.
- Overview keeps the screen it had. The detail views show their kind in full on any terminal width, so
  a narrow terminal no longer loses disk I/O, temperatures, power rails, fans, pressure, Wi-Fi or TCP
  connect times; swap, partition counts and the GPU's maximum clock reach the live view for the first
  time. Long sensor, rail and path names keep their column; the bars give up the room instead.
- A view longer than the terminal scrolls: the up and down arrows move a line, PgUp/PgDn a page, Home
  and End its ends, and the last line says how much is out of sight. Before, a host with many sensors
  or cores ended in `+N more lines · enlarge the terminal` with no way to reach the rest.
- The offline banner wraps instead of being cut, so the errno, the retry interval and the name of the
  script to start survive on a terminal narrower than the 111 columns it needs.
- The detail beside each Overview reading takes the width the terminal has free, instead of a fixed 16
  columns that cut `x86_pkg_temp · hottest of 38` to `x86_pkg_temp · h`.
- `--once`, pipes, Windows and `/text` are unchanged: the plain screen with every section.
- Five fixes from running 1.0.0's package on an x86_64 PC (22 logical CPUs, 31 temperature channels, an
  `acpi_fan` without a tachometer): Storage reports the filesystem's read-only state rather than this
  process's mount; history keeps every core's series inside its 64-series limit; a fan speed the
  firmware withholds is reported as `no_data` instead of failing the group; the live view draws no more
  lines than the terminal has rows; and the service integration tests no longer read the host's sensors.
- The README says what to check when another machine cannot reach the service.

## 1.0.0 — 2026-10-10

First release. From this version the HTTP API (its `schema_version` contracts), the `platmon.ini` keys and
the `platmon` command's options follow MAJOR.MINOR.PATCH: a breaking change needs a new major version.
A `v0.1.0` tag was cut while validating the packaging and never published; 1.0.0 includes everything below.

- First versioned distribution of the existing platform monitor.
- Debian package with a systemd service, standalone CLI and preserved INI configuration.
- Server and CLI `--version`, source archive, build manifest and SHA-256 checksums.
- Source installer stages updates and restores previous code/unit on startup failure.
- Package and release validation workflows; an explicit version tag creates a draft release.
- Release tags must reference commits included in main; existing version tags are protected from updates/deletion.
- Web viewer redesign: sticky header with a Live/Partial/Offline status, banners for connection loss and partial
  collection, warning/critical levels with threshold ticks, a Needs attention strip, tables, chart hover readout,
  a bottom tab bar on narrow screens and the running version in the footer.
- `[thresholds]` in `platmon.ini` sets the web page's warning and critical levels; an empty temperature keeps
  the board default.
- `platmon` live terminal view on interactive terminals: colored levels from the service's `[thresholds]`,
  Needs attention, core grid, tables, sparklines, header status and an offline banner; `q` quits,
  `NO_COLOR` and `PLATMON_ASCII` are honored. `--once`, pipes and `/text` are unchanged.
- `/api/status` reports the configured `levels`; an empty `[thresholds]` temperature is sent as the board's
  default, decided once by the server.
- Network rows on the web Overview and in `platmon` list the busiest interfaces first.
