const $ = id => document.getElementById(id);
// The Overview readings' and the table columns' labels, long (here) and short (the terminal's), and the number
// formats: frontends/ui-spec.json's metrics, columns and formats (tests/frontends/test_ui_spec.py).
const METRICS = {cpu: ['CPU', 'CPU'], memory: ['RAM', 'RAM'], gpu: ['GPU', 'GPU'], filesystem: ['Root filesystem', 'DISK'],
  temperature: ['Temperature', 'TEMP']};
const COLUMNS = {rx: ['↓ Receive', '↓ RX'], tx: ['↑ Send', '↑ TX'], packets: ['Packets/s rx · tx', 'PKT/S rx · tx'],
  errors: ['Errors · drops', 'ERR · DROP'], read: ['Read', 'READ'], write: ['Write', 'WRITE'], ops: ['Ops/s r · w', 'OPS/S r · w'],
  io_time: ['I/O time', 'I/O TIME']};
const FORMATS = {per_s_decimals: 0, size_units: ['G', 'M', 'K']};
// bytes in the unit that fits them: 45.1G, 14M, 512K (a 100 MiB partition is not "0.1G")
const size = b => {
  for (const [i, unit] of FORMATS.size_units.entries()) if (b >= 2 ** (30 - 10 * i)) return (b / 2 ** (30 - 10 * i)).toFixed(i ? 0 : 1) + unit;
  return b ? b.toFixed(0) + 'B' : '0';  // none at all needs no unit: "0 / 15.3G"
};
const SYSTEM_FIELDS = ['os', 'kernel', 'arch', 'hostname', 'l4t'];  // frontends/ui-spec.json system_fields
const esc = v => String(v).replace(/[&<>"']/g, c => `&#${c.charCodeAt(0)};`);
const kv = (k, v) => `<div class="kv"><span>${k}</span><span>${v}</span></div>`;
// a grid table: cols is the CSS column template; a row is its cells' HTML, idle rows are dimmed
const tr = (cells, cls = '') => `<div class="tr${cls}">${cells.map(c => `<span>${c}</span>`).join('')}</div>`;
const table = (cols, head, rows, minWidth = 0) => `<div class="table"><div style="--cols:${cols}${minWidth ? `;min-width:${minWidth}px` : ''}">` +
  tr(head, ' th') + rows.join('') + '</div></div>';
const muted = text => `<span class="muted">${text}</span>`;

// Status levels: ok below warn, warn from warn, crit from crit. Instantaneous values, no persistence.
// The server fills them in from [thresholds] in platmon.ini, temperature with its board's default when
// not set there (the server's board table, native/src/config.rs); these generic defaults apply only to a page not served by platmon.
// They and the tab order and labels in index.html are frontends/ui-spec.json's (tests/frontends/test_ui_spec.py).
const LIMITS = {cpu: [80, 90], gpu: [80, 90], memory: [80, 90], filesystem: [80, 90], temperature: [80, 90],
  battery: [20, 10], wifi: [-70, -80]};
try { Object.assign(LIMITS, JSON.parse($('levels').textContent)); } catch (e) {}  // not served by platmon
LIMITS.temperature ||= [80, 90];
const level = (v, [warn, crit]) => v >= crit ? 'crit' : v >= warn ? 'warn' : 'ok';
// battery and wifi: the low reading is the bad one, so a level is reached at or below it (warning above critical)
const lowLevel = (v, [warn, crit]) => v <= crit ? 'crit' : v <= warn ? 'warn' : 'ok';
const LOW_IS_BAD = ['battery', 'wifi'];  // frontends/ui-spec.json levels.low_is_bad
// a named reading's level against its LIMITS, low or high as the spec says; the only caller of lowLevel
const levelOf = (name, v) => (LOW_IS_BAD.includes(name) ? lowLevel : level)(v, LIMITS[name]);
const textLevel = lv => lv === 'ok' ? '' : ' t-' + lv;
const pctOf = (used, total) => total ? 100 * used / total : 0;
// a bar on a 0–100 scale; limits add the level color and, unless ticks is false, two threshold ticks;
// lv, when given, is the level to color it with (a lowLevel reading's)
const bar = (pct, limits, ticks = true, lv = limits ? level(pct, limits) : 'ok') => `<div class="bar"><div class="${lv}" style="width:${Math.max(0, Math.min(pct, 100)).toFixed(1)}%"></div>` +
  (limits && ticks ? limits.map(t => `<span style="left:${t}%"></span>`).join('') : '') + '</div>';
const meter = (label, text, pct, limits) =>
  `<div class="meter"><div class="meter-head"><span>${label}</span><span>${text}</span></div>${bar(pct, limits)}</div>`;
const mhz = hz => hz ? (hz / 1e6).toFixed(0) + ' MHz' : '';
const uptimeText = seconds => {
  const up = Math.floor(seconds);
  return `${Math.floor(up / 86400)}d ${String(Math.floor(up % 86400 / 3600)).padStart(2, '0')}:${String(Math.floor(up % 3600 / 60)).padStart(2, '0')}`;
};

const TABS = ['overview', 'resources', 'network', 'storage', 'thermal', 'power', 'system'];
let activeTab = 'overview', latestStats = null;
// The views whose cards come from /api/observations. A view holding such a card must be listed here, or
// the page never asks for them while that view is open and the card stays empty: the fetch is gated on
// the view so a view that shows none costs no request (see pollObs).
const OBS_TABS = ['network', 'storage', 'power'];
const wantsObs = () => OBS_TABS.includes(activeTab);
const visible = () => document.visibilityState === 'visible';
function activateTab(tab, save = true) {
  if (!TABS.includes(tab)) return;
  activeTab = tab;
  for (const name of TABS) {
    $('tab-' + name).setAttribute('aria-selected', String(name === tab));
    $('tab-' + name).tabIndex = name === tab ? 0 : -1;
    $('panel-' + name).hidden = name !== tab;
  }
  if (save && location.hash !== '#' + tab) history.replaceState(history.state, '', '#' + tab);
  $('tab-' + tab).scrollIntoView({block: 'nearest', inline: 'nearest'});
  // Switching views reuses data and polling deadlines, never creates another timer.
  if (!visible()) return;
  renderActive(); renderObservations(); renderHistory();
  pollObs(); pollHist();
}
// why CPU rows are missing: the service compares /proc/stat readings, so the first one has none (same as cli.py)
const CPU_REASONS = {warmup: 'warming up', counter_regressed: 'counter went backwards', no_ticks: 'no ticks counted',
  invalid_interval: 'invalid interval', gap: 'restarting after a gap'};
function cpuNote(s) {
  const groups = {};
  for (const u of (s.cpu_sampling && s.cpu_sampling.unavailable) || [])
    (groups[CPU_REASONS[u.reason] || u.reason] ||= []).push('CPU' + u.id);
  const whys = Object.keys(groups);
  if (!whys.length) return '';
  return 'CPU sampling: ' + (!s.cpu.length && whys.length === 1 ? whys[0]
    : whys.map(why => groups[why].join(' ') + ' ' + why).join('; '));
}

// network interfaces and disks with the rates the server computed (same wording as cli.py); a counter
// without a rate says why, it is never shown as 0. I/O time is the share of the window with I/O in flight.
const RATE_REASONS = {warmup: 'warming up', gap: 'restarting after a gap', counter_regressed: 'counter went backwards',
  invalid_interval: 'invalid interval', identity_unavailable: 'identity unknown', namespace_changed: 'namespace changed'};
const perS = v => {
  let i = 0;
  while (Math.abs(v) >= 1024 && i < 3) { v /= 1024; i++; }
  return (i ? v.toFixed(1) : v.toFixed(0)) + ' ' + ['B/s', 'KiB/s', 'MiB/s', 'GiB/s'][i];
};
const why = x => esc(RATE_REASONS[x.reason] || x.reason);
const listOf = (obj, key) => obj && Array.isArray(obj[key]) ? obj[key] : [];
const idle = r => r && !r.rx_bytes_per_s && !r.tx_bytes_per_s ? ' idle' : '';
const netCaption = s => {
  const timed = listOf(s.network, 'interfaces').find(i => Number.isFinite(i.window_ms));
  // the host's interfaces on Windows (scope "host"), else this process's network namespace (Linux)
  const whose = s.network && s.network.scope && s.network.scope.kind === 'host' ? 'This host' : "This process's network namespace";
  return whose + (timed ? ` · window ${(timed.window_ms / 1000).toFixed(3)} s` : '') + ' · errors and drops are totals';
};
function netRows(s) {
  // the server's order, loopback last, as the terminal: a row keeps its place whatever the traffic does
  const items = listOf(s.network, 'interfaces').slice().sort((a, b) => (a.name === 'lo') - (b.name === 'lo'));
  return items.length ? table('minmax(90px, 1fr) 110px 110px 150px 110px',
    ['Interface', COLUMNS.rx[0], COLUMNS.tx[0], COLUMNS.packets[0], COLUMNS.errors[0]], items.map(i => {
      const r = i.rates, total = k => ((i.rx || {})[k] || 0) + ((i.tx || {})[k] || 0);
      const errs = `${total('errors')} · ${total('dropped')}`;
      return tr([esc(i.name), r ? perS(r.rx_bytes_per_s) : why(i), r ? perS(r.tx_bytes_per_s) : '',
        r ? muted(`${r.rx_packets_per_s.toFixed(FORMATS.per_s_decimals)} · ${r.tx_packets_per_s.toFixed(FORMATS.per_s_decimals)}`) : '',
        total('errors') || total('dropped') ? `<span class="t-warn">${errs}</span>` : muted(errs)], idle(r));
    }), 600) : '';
}
function diskRows(s) {
  const items = listOf(s.disk_io, 'disks');
  return items.length ? table('minmax(90px, 1fr) 110px 110px 140px 80px', ['Disk', COLUMNS.read[0], COLUMNS.write[0], COLUMNS.ops[0], COLUMNS.io_time[0]],
    items.map(d => {
      const r = d.rates;
      return tr([esc(d.name), r ? perS(r.read_bytes_per_s) : why(d), r ? perS(r.write_bytes_per_s) : '',
        r ? muted(`${r.reads_per_s.toFixed(FORMATS.per_s_decimals)} · ${r.writes_per_s.toFixed(FORMATS.per_s_decimals)}`) : '', r ? (100 * r.io_time_ratio).toFixed(1) + ' %' : '']);
    }), 560) : '';
}

// Low-frequency groups (/api/observations) change on their own cadence: asked for at most every 10 s, only
// while a view needs them, on the same 1 s timer as the age display; a 404 is not asked again.
// Their age is the server's data_age_ms plus browser time since that answer, like the sample age.
let obs = null, obsAt = 0, obsAsked = -Infinity, obsSupported = true, obsRequest = null;
async function pollObs() {
  const now = performance.now();
  if (obsRequest || !obsSupported || !visible() || !wantsObs() || now - obsAsked < 10000) return;
  obsAsked = now;
  const ctl = obsRequest = new AbortController(), mine = epoch;
  const timer = setTimeout(() => ctl.abort(), TIMEOUT_MS);
  try {
    const r = await fetch('api/observations', {signal: ctl.signal, cache: 'no-store'});
    const body = r.ok ? await r.json() : null;
    if (mine !== epoch || ctl.signal.aborted) return;
    if (r.status === 404) { obsSupported = false; obs = null; }
    else if (r.ok) { obs = body; obsAt = performance.now(); }
    else obs = null;
  } catch (e) { if (mine === epoch) obs = null; } finally {
    clearTimeout(timer); obsRequest = null;
  }  // the main view goes on without it
  renderObservations();
}
function observationStale(g) {
  const o = g.observation;
  return o.stale || (Number.isFinite(g.stale_after_ms) && o.data_age_ms + performance.now() - obsAt > g.stale_after_ms);
}
function observationAge(group) {
  const g = obs && obs.groups && obs.groups[group];
  if (!g || !g.observation) return '';
  const age = Math.round((g.observation.data_age_ms + performance.now() - obsAt) / 1000);
  return `observed ${age} s ago${observationStale(g) ? ' (not current)' : ''}`;
}
// TCP connect time to the configured targets (not ICMP ping): the latest attempt, and recent failures
function probeRows() {
  const g = obs && obs.groups && obs.groups.probe, o = g && g.observation, d = g && g.data;
  const items = d && Array.isArray(d.targets) ? d.targets : [];
  if (!o || !items.length) return '';
  return table('minmax(0, 1fr) 80px 80px', ['Target', 'Latest', 'Failed'], items.map(t =>
    tr([esc(t.address.includes(':') ? `[${t.address}]:${t.port}` : `${t.address}:${t.port}`),
      t.connect_ms != null ? t.connect_ms.toFixed(1) + ' ms' : esc(t.reason),
      `<span class="${t.failures ? 't-warn' : 'muted'}">${t.failures}/${t.attempts}</span>`])));
}
// the signal while connected, never the last one after; a value without dBm is shown without a unit or bar
const WIFI_DBM = [-90, -30];  // the bar's scale, weak to strong: frontends/ui-spec.json scales.wifi_dbm
function wifiRows() {
  const g = obs && obs.groups && obs.groups.wifi, o = g && g.observation, d = g && g.data;
  const items = d && Array.isArray(d.interfaces) ? d.interfaces : [];
  if (!o || !items.length) return '';
  return '<div class="meters">' + items.map(i => {
    const state = i.connected !== true ? (i.connected === false ? 'not connected' : esc(i.connection_state || 'unknown'))
      : i.signal_dbm != null ? i.signal_dbm + ' dBm' : i.signal_raw != null ? `signal ${i.signal_raw} (unit not reported)` : 'signal n/a';
    const lv = i.connected === true && i.signal_dbm != null ? levelOf('wifi', i.signal_dbm) : 'ok';
    return `<div class="meter"><div class="meter-head"><span class="mono">${esc(i.name)}</span><span${lv === 'ok' ? '' : ` class="t-${lv}"`}>${state}</span></div>` +
      (i.connected === true && i.signal_dbm != null ? bar((i.signal_dbm - WIFI_DBM[0]) / (WIFI_DBM[1] - WIFI_DBM[0]) * 100, null, false, lv) : '') +
      (i.connected === true ? `<div class="detail">Connected${i.link_quality != null ? ' · link quality ' + i.link_quality : ''}</div>` : '') + '</div>';
  }).join('') + '</div>';
}
// batteries and external supplies, observed on their own slow cadence: one reading is one firmware call,
// so the age is shown. The charge is coloured by levelOf (low is bad): for a battery the low reading is the bad one.
function batteryRows() {
  const g = obs && obs.groups && obs.groups.battery, o = g && g.observation, d = g && g.data;
  const cells = d && Array.isArray(d.batteries) ? d.batteries : [];
  const external = d && Array.isArray(d.external) ? d.external : [];
  if (!o || !(cells.length || external.length)) return '';
  const rows = cells.map(b => {
    const head = b.present === false ? 'not present'
      : b.percent != null ? b.percent + ' %' : esc(b.capacity_level || 'charge n/a');
    const lv = b.present !== false && b.percent != null ? levelOf('battery', b.percent) : 'ok';
    const open = `<div class="meter"><div class="meter-head"><span class="mono">${esc(b.name)}</span><span${lv === 'ok' ? '' : ` class="t-${lv}"`}>${head}</span></div>`;
    if (b.present === false) return open + '</div>';
    const full = b.charge_full_uah || b.energy_full_uwh, design = b.charge_full_design_uah || b.energy_full_design_uwh;
    const detail = [b.voltage_uv != null ? (b.voltage_uv / 1e6).toFixed(2) + ' V' : '',
      b.current_ua != null ? (b.current_ua / 1e6).toFixed(2) + ' A' : '',
      b.power_uw != null ? (b.power_uw / 1e6).toFixed(2) + ' W' : '',
      b.cycle_count != null ? b.cycle_count + ' cycles' : '',
      b.temp_c != null ? b.temp_c.toFixed(1) + ' °C' : '',
      full && design ? Math.round(full * 100 / design) + ' % of design' : ''].filter(Boolean).join(' · ');
    return open + (b.percent != null ? bar(b.percent, LIMITS.battery, true, lv) : '') +
      `<div class="detail">${esc(b.status || 'status n/a')}${detail ? ' · ' + detail : ''}</div></div>`;
  });
  if (external.length) {
    rows.push('<div class="meter"><div class="meter-head"><span>External power</span></div><div class="detail">' +
      external.map(e => `${esc(e.name)} ${e.online ? 'on' : e.online === false ? 'off' : 'n/a'}`).join(' · ') +
      '</div></div>');
  }
  return '<div class="meters">' + rows.join('') + '</div>';
}
const fsPct = f => f.total_bytes ? pctOf(f.used_bytes, f.total_bytes) : -1;
function storageRows() {
  const g = obs && obs.groups && obs.groups.storage, o = g && g.observation, d = g && g.data;
  if (!o || !d) return '';
  const fss = Array.isArray(d.filesystems) ? d.filesystems : [], parts = Array.isArray(d.partitions) ? d.partitions : [];
  if (!fss.length && !parts.length) return '';
  // the server's order, as the terminal: a filesystem keeps its place as usage changes
  return fss.map(f => {
    const m = f.mount_points, pct = fsPct(f);
    return '<div class="fs"><div><div class="fs-name"><span>' + esc(m[0].path) + '</span>' +
      (m[0].read_only ? '<span class="badge">ro</span>' : '') + (m.length > 1 ? muted(`+${m.length - 1} more`) : '') + '</div>' +
      `<div class="detail">${esc(f.fstype)} · ${esc(f.device || f.major + ':' + f.minor)}</div></div>` +
      (f.total_bytes != null ? meter(`${size(f.used_bytes)} / ${size(f.total_bytes)} · ${pct.toFixed(0)} %`,
        `${size(f.available_bytes)} free`, pct, LIMITS.filesystem) : muted('capacity unknown')) + '</div>';
  }).join('') + (parts.length ? '<h3>Partitions</h3>' + partitionsByDisk(parts) : '');
}
// One line a disk, the table folded under it: a board with a dozen boot and recovery partitions (a Jetson has 15)
// would otherwise fill the view with rows that are not mounted, as the terminal's count already avoids.
function partitionsByDisk(parts) {
  const disks = {};
  for (const p of parts) (disks[p.disk || ''] ||= []).push(p);
  return Object.entries(disks).map(([disk, items]) => {
    const mounted = items.filter(p => p.mount_points.length).length;
    return `<details><summary><span class="disk">${esc(disk || 'partitions')}</span>${items.length} partition${items.length === 1 ? '' : 's'} · ${mounted} mounted</summary>` +
      table('minmax(0, 1fr) 80px minmax(0, 1fr)', ['Partition', 'Size', 'Mounted at'],
        items.map(p => tr([esc(p.name), size(p.size_bytes), p.mount_points.length ? esc(p.mount_points[0] +
          (p.mount_points.length > 1 ? ` +${p.mount_points.length - 1} more` : '')) : muted('not mounted')]))) + '</details>';
  }).join('');
}

// One bounded history cache shared across detail views, fetched at most every 10 s.
// Overview does not fetch history. A null is a gap in the line, never 0.
let hist = null, histAt = 0, histAsked = -Infinity, histSupported = true, histRequest = null;
const HIST_PREFIXES = {resources: ['cpu/', 'gpu/', 'npu/', 'memory/'], network: ['network/', 'observation/wifi/', 'observation/probe/'],
  storage: ['disk_io/', 'observation/storage/'], thermal: ['temperature/'],
  power: ['power/', 'observation/battery/']};
// One button per kind of series a view can draw, in this order, labelled with how many it covers. A
// viewer turns a kind off to take its graphs out of the list; single series are not picked one at a time.
const HIST_GROUPS = [['cpu/', 'CPU cores'], ['gpu/', 'GPU'], ['npu/', 'NPU'], ['memory/', 'RAM'], ['network/', 'Interfaces'],
  ['observation/wifi/', 'Wi-Fi'], ['observation/probe/', 'TCP connect'], ['disk_io/', 'Disk I/O'],
  ['observation/storage/', 'Filesystems'], ['temperature/', 'Temperature'], ['power/', 'Power rails'],
  ['observation/battery/', 'Battery']];
const histOff = new Set();  // kinds a viewer turned off; every kind of a view starts on
const wantsHistory = () => !!HIST_PREFIXES[activeTab];
const historyMatches = id => (HIST_PREFIXES[activeTab] || []).some(prefix => id.startsWith(prefix));
const HIST_LABEL = [[/^cpu\/(\d+)\/usage$/, m => 'CPU' + m[1]],
  [/^gpu\/usage$/, () => 'GPU'],
  [/^npu\/usage$/, () => 'NPU'],
  [/^observation\/storage\/([^/]+)\/[^/]+\/(used_bytes|available_bytes)$/, m => `FS ${m[1]} ${m[2] === 'used_bytes' ? 'used' : 'free'}`],
  [/^observation\/storage\/(Volume\{[^/]+\})\/(used_bytes|available_bytes)$/, m => `FS ${m[1]} ${m[2] === 'used_bytes' ? 'used' : 'free'}`],
  [/^observation\/wifi\/[^/]+\/\d+\/([^/]+)\/signal_dbm$/, m => `${m[1]} signal`],
  [/^observation\/probe\/([^/]+)\/connect_ms$/, m => `TCP ${m[1]}`],
  [/^observation\/battery\/([^/]+)\/percent$/, m => `${m[1]} charge`],
  [/^observation\/battery\/([^/]+)\/charge_now_uah$/, m => `${m[1]} charge now`],
  [/^observation\/battery\/([^/]+)\/energy_now_uwh$/, m => `${m[1]} energy now`],
  [/^observation\/battery\/([^/]+)\/power_uw$/, m => `${m[1]} draw`],
  [/^memory\/used_bytes$/, () => 'RAM used'],
  [/^temperature\/name:(.+)$/, m => 'temp ' + m[1]],
  [/^temperature\/(.+)$/, m => 'temp ' + sensorName('temperature', m[1])],
  [/^power\/name:(.+)$/, m => 'rail ' + m[1]],
  [/^power\/(.+)$/, m => 'rail ' + sensorName('power', m[1])],
  [/^network\/[^/]+\/\d+\/([^/]+)\/(rx|tx)_bytes_per_s$/, m => `${m[1]} ${m[2]}`],
  [/^disk_io\/[^/]+\/([^/]+)\/(read|write)_bytes_per_s$/, m => `${m[1]} ${m[2]}`],
  [/^disk_io\/([^/]+)\/(read|write)_bytes_per_s$/, m => `${m[1]} ${m[2]}`]];  // Windows: PhysicalDriveN
// History keys a sensor by its source id (docs/reference/history.md); its name is the sensor_meta pointer with that id
function sensorName(group, sid) {
  const meta = latestStats && latestStats.sensor_meta && typeof latestStats.sensor_meta === 'object' ? latestStats.sensor_meta : {};
  const ptr = Object.keys(meta).find(p => p.startsWith('/' + group + '/') && meta[p] && meta[p].id === sid);
  return ptr ? ptr.slice(group.length + 2).replace(/~1/g, '/').replace(/~0/g, '~') : sid;
}
const histValue = (id, v) => id.startsWith('temperature') ? v.toFixed(1) + ' °C'
  : id.startsWith('power/') ? v.toFixed(2) + ' W'
  : id.endsWith('/percent') ? v.toFixed(0) + ' %'
  : id.endsWith('_uah') ? (v / 1e3).toFixed(0) + ' mAh' : id.endsWith('_uwh') ? (v / 1e3).toFixed(0) + ' mWh'
  : id.endsWith('_uw') ? (v / 1e6).toFixed(2) + ' W'
  : id.startsWith('cpu/') || id.startsWith('gpu/') || id.startsWith('npu/') ? v.toFixed(1) + ' %'
  : id.includes('/wifi/') ? v.toFixed(1) + ' dBm' : id.includes('/probe/') ? v.toFixed(1) + ' ms'
  : id.startsWith('memory') || id.includes('/storage/') ? size(v) : perS(v);
// x of a point on the 0–200 chart: spaced by its age, so irregular intervals stay irregular
const histX = (points, p) => {
  const oldest = points[0][1], newest = points[points.length - 1][1];
  return oldest > newest ? 200 * (oldest - p[1]) / (oldest - newest) : 0;
};
// Percentages and temperatures are drawn on the 0–100 scale of their bars, so a reading that moves by a few
// points looks like it, not like a swing across the chart; values with no top (bytes/s, W) use their own range.
const FIXED = id => /^(cpu|gpu|npu)\//.test(id) || id.startsWith('temperature') || id.endsWith('/percent');
function spark(points, fixed = false) {
  const vs = points.map(p => p[2]).filter(v => v != null), lo = fixed ? 0 : Math.min(...vs), hi = fixed ? 100 : Math.max(...vs);
  const svg = paths => `<svg class="spark" viewBox="0 0 200 28" preserveAspectRatio="none">${paths}</svg>`;
  if (!vs.length) return svg('');  // keeps the chart's height
  const y = v => hi > lo ? 26 - 24 * (Math.max(lo, Math.min(v, hi)) - lo) / (hi - lo) : 14;
  let line = '', area = '', run = [];
  const close = () => { if (run.length > 1) area += `M${run[0][0]},28L${run.map(p => p.join(',')).join('L')}L${run[run.length - 1][0]},28Z`; run = []; };
  points.forEach(p => {
    if (p[2] == null) { close(); return; }
    const xy = [histX(points, p).toFixed(1), y(p[2]).toFixed(1)];
    line += `${run.length ? 'L' : 'M'}${xy.join(',')}`;
    run.push(xy);
  });
  close();
  return svg((area ? `<path class="area" d="${area}"/>` : '') + `<path class="line" d="${line}"/>`);
}
function chartOf(id, points, rule) {
  const latest = points[points.length - 1], last = latest[2], vs = points.map(p => p[2]).filter(v => v != null);
  const lo = vs.length && histValue(id, Math.min(...vs)), hi = vs.length && histValue(id, Math.max(...vs));
  return `<div class="card chart"><div class="chart-head"><span>${esc(rule[1](id.match(rule[0])))}</span><span>${last == null ? 'no value' : histValue(id, last)}</span></div>` +
    `<div class="plot" data-series="${esc(id)}">${spark(points, FIXED(id))}</div>` +
    `<div class="chart-foot"><span>${!vs.length ? '' : lo === hi ? lo : lo + ' – ' + hi}</span>` +
    `<span data-history-age="${Number(latest[1])}">${historyAge(latest[1])}</span></div></div>`;
}
// Many cores: one chart of their mean and the busiest core at each point, on the cores' 0–100 scale with the warning
// and critical levels dashed; each core's own chart only when asked for (a 64-core board would draw 64).
const CORES_FOLDED = 8;
let histCoresOpen = false;
function coresChart(ids, series) {
  const first = series[ids[0]], at = k => ids.map(id => series[id][k] && series[id][k][2]).filter(v => v != null);
  const mean = first.map((p, k) => { const vs = at(k); return [p[0], p[1], vs.length ? vs.reduce((a, v) => a + v, 0) / vs.length : null]; });
  const max = first.map((p, k) => { const vs = at(k); return [p[0], p[1], vs.length ? Math.max(...vs) : null]; });
  const path = pts => {  // a point with no core reading is a gap in both lines, never 0
    let out = '', gap = true;
    for (const p of pts) {
      if (p[2] == null) { gap = true; continue; }
      out += `${gap ? 'M' : 'L'}${histX(pts, p).toFixed(1)},${(26 - 24 * Math.min(p[2], 100) / 100).toFixed(1)}`;
      gap = false;
    }
    return out;
  };
  const guides = LIMITS.cpu.map(t => `<path class="guide" d="M0,${(26 - 24 * t / 100).toFixed(1)}L200,${(26 - 24 * t / 100).toFixed(1)}"/>`).join('');
  const last = pts => pts[pts.length - 1][2], lv = last(max) == null ? 'ok' : level(last(max), LIMITS.cpu);
  return '<div class="card chart"><div class="chart-head"><span>CPU mean · busiest core</span>' +
    `<span>${last(mean) == null ? 'no value' : last(mean).toFixed(1) + ' %'} · ${last(max) == null ? '–' : last(max).toFixed(1) + ' %'}</span></div>` +
    `<div class="plot"><svg class="spark" viewBox="0 0 200 28" preserveAspectRatio="none">${guides}` +
    `<path class="line" d="${path(mean)}"/><path class="max ${lv}" d="${path(max)}"/></svg></div>` +
    `<div class="chart-foot"><span class="legend"><b>━</b> mean · <b class="${textLevel(lv).trim()}">━</b> busiest of ${ids.length}</span>` +
    `<button data-cores aria-expanded="${histCoresOpen}">${histCoresOpen ? 'Hide' : 'Show'} each core</button></div></div>`;
}
// One section per kind of series, in the button row's order: a single RAM graph never sits in a wall of cores.
function histRows() {
  const series = hist && hist.series && typeof hist.series === 'object' ? hist.series : {};
  const sections = [];
  for (const [prefix, label] of HIST_GROUPS) {
    if (histOff.has(prefix)) continue;
    const rows = [], ids = [];
    for (const [id, points] of Object.entries(series)) {
      const rule = HIST_LABEL.find(([re]) => re.test(id));
      if (!rule || !historyMatches(id) || histGroup(id) !== prefix
        || !Array.isArray(points) || !points.length) continue;
      rows.push(chartOf(id, points, rule));
      ids.push(id);
    }
    if (prefix === 'cpu/' && ids.length > CORES_FOLDED && ids.every(id => series[id].length === series[ids[0]].length)) {
      rows.splice(0, rows.length, coresChart(ids, series), ...(histCoresOpen ? rows : []));
    }
    if (rows.length) sections.push(`<div class="hist-group"><h3>${esc(label)}</h3><div>${rows.join('')}</div></div>`);
  }
  // Every kind off leaves the panel with its buttons, so the viewer can turn one back on.
  return sections.join('') || (histMatching().length ? '<div class="muted">Every group is off · turn one on above</div>' : '');
}
// The series this view can draw, labelled ones only: the list and the buttons agree on it.
const histMatching = () => Object.keys((hist && hist.series && typeof hist.series === 'object' ? hist.series : {}))
  .filter(id => historyMatches(id) && HIST_LABEL.some(([re]) => re.test(id)));
const histGroup = id => (HIST_GROUPS.find(([prefix]) => id.startsWith(prefix)) || [])[0];
function histButtons() {
  const ids = histMatching();
  const groups = HIST_GROUPS.map(([prefix, label]) => [prefix, label, ids.filter(id => id.startsWith(prefix)).length])
    .filter(([, , count]) => count);
  // A view with one kind has nothing to filter against, so it gets no buttons.
  $('history-groups').innerHTML = groups.length < 2 ? '' : groups.map(([prefix, label, count]) =>
    `<button data-group="${prefix}" aria-pressed="${!histOff.has(prefix)}">${esc(label)} ${count}</button>`).join('');
}
const histDraw = () => { $('hist').innerHTML = histRows(); histButtons(); };
const historyAge = age => `latest point ${Math.round((age + performance.now() - histAt) / 1000)} s ago`;
function renderHistory() {
  if (!visible()) return;
  $('history-panel').hidden = !wantsHistory() || !hist;
  if ($('history-panel').hidden) return;
  $('history-cap').textContent = `Last ${Math.round(hist.retention_s / 60)} min · each chart has its own scale · gaps = no sample`;
  histDraw();
  $('history-panel').hidden = !$('hist').innerHTML;
}
// hover or touch: the nearest point's value and age above the chart
function readout(event) {
  document.querySelectorAll('#hist .cursor, #hist .tip').forEach(e => e.remove());
  const plot = event.target.closest && event.target.closest('.plot');
  const id = plot && plot.dataset.series, points = id && hist && hist.series[id];
  if (!points) return;
  const box = plot.getBoundingClientRect(), at = 200 * (event.clientX - box.left) / box.width;
  let best = null;
  for (const p of points) if (p[2] != null && (!best || Math.abs(histX(points, p) - at) < Math.abs(histX(points, best) - at))) best = p;
  if (!best) return;
  const x = histX(points, best) / 2, shift = x < 15 ? 0 : x > 85 ? -100 : -50;
  const when = best === points[points.length - 1] ? 'now' : Math.round((best[1] + performance.now() - histAt) / 1000) + ' s ago';
  plot.insertAdjacentHTML('beforeend', `<span class="cursor" style="left:${x}%"></span>` +
    `<span class="tip" style="left:${x}%;transform:translateX(${shift}%)">${esc(histValue(id, best[2]))} · ${when}</span>`);
}
async function pollHist() {
  const now = performance.now();
  if (histRequest || !histSupported || !visible() || !wantsHistory() || now - histAsked < 10000) return;
  histAsked = now;
  const ctl = histRequest = new AbortController(), mine = epoch;
  const timer = setTimeout(() => ctl.abort(), TIMEOUT_MS);
  try {
    const r = await fetch('api/history?points=120', {signal: ctl.signal, cache: 'no-store'});
    const body = r.ok ? await r.json() : null;
    if (mine !== epoch || ctl.signal.aborted) return;
    if (r.status === 404) { histSupported = false; hist = null; }
    else if (r.ok) { hist = body; histAt = performance.now(); }
    else hist = null;
  } catch (e) { if (mine === epoch) hist = null; } finally {
    clearTimeout(timer); histRequest = null;
  }
  renderHistory();
}

// pressure stall information: the kernel's 10 s averages of the share of time tasks were stalled (not usage)
function psiRows(s) {
  const res = s.pressure && s.pressure.resources && typeof s.pressure.resources === 'object' ? s.pressure.resources : {};
  const rows = Object.entries(res).map(([name, r]) => tr([esc(name), r.some.avg10.toFixed(1) + ' %', muted(r.full ? r.full.avg10.toFixed(1) + ' %' : '—')]));
  return rows.length ? table('minmax(0, 1fr) 80px 80px', ['Resource', 'Some', 'Full'], rows) : '';
}

// optional groups that could not read everything, as in cli.py; nothing for absent sensors or older servers
function collectionNote(s) {
  const c = s.collectors && typeof s.collectors === 'object' ? s.collectors : {};
  return Object.entries(c).filter(([name, v]) => name !== 'core' && v && (v.state === 'partial' || v.state === 'error'))
    .map(([name, v]) => name + ' ' + v.state).join(', ');
}

function hideEmptyPanels() {
  document.querySelectorAll('[data-card]').forEach(sec => sec.hidden = !sec.lastElementChild.innerHTML);
  $('network-empty').hidden = ['net', 'wifi', 'probe'].some(id => $(id).innerHTML);
  $('thermal-empty').hidden = !!$('temp').innerHTML;
  $('power-empty').hidden = ['pwr', 'batt'].some(id => $(id).innerHTML);
}

// The Overview readings, in the web page's and the terminal's order: {label, sub, value, unit, limits, detail, tab, name}
// (value null: unavailable). CPU's detail names its busiest core, the signal its mean hides.
function readings(s) {
  const cpus = s.cpu.filter(c => Number.isFinite(c.usage)), m = s.memory, d = s.disk, note = cpuNote(s), out = [];
  let detail = note;
  if (cpus.length) {
    const top = cpus.reduce((a, c) => c.usage > a.usage ? c : a), lv = level(top.usage, LIMITS.cpu);
    const more = cpus.filter(c => c !== top && level(c.usage, LIMITS.cpu) !== 'ok').length;
    detail = `Busiest <span class="${lv === 'ok' ? '' : 't-' + lv}">CPU${top.id} ${top.usage.toFixed(1)} %</span>` +
      (more ? ` · ${more} more ≥ ${LIMITS.cpu[0]} %` : '') + (note ? ' · ' + esc(note) : '');
  }
  out.push({label: METRICS.cpu[0], sub: s.cpu.length + (s.cpu.length === 1 ? ' core' : ' cores'), unit: '%', limits: LIMITS.cpu,
    value: cpus.length ? cpus.reduce((sum, c) => sum + c.usage, 0) / cpus.length : null, detail, tab: 'resources'});
  out.push({label: METRICS.memory[0], sub: size(m.total), value: pctOf(m.used, m.total), unit: '%', limits: LIMITS.memory,
    detail: `${size(m.used)} / ${size(m.total)}`, tab: 'resources'});
  if (s.gpu) out.push({label: METRICS.gpu[0], sub: mhz(s.gpu.freq), value: s.gpu.usage, unit: '%', limits: LIMITS.gpu, detail: '', tab: 'resources'});
  // used / total, as the terminal: "free" is the filesystem's available space, which only the Storage view has
  out.push({label: METRICS.filesystem[0], sub: size(d.total), value: pctOf(d.used, d.total), unit: '%', limits: LIMITS.filesystem,
    detail: `${size(d.used)} / ${size(d.total)}`, tab: 'storage', name: '/'});
  const temps = hottest(s);
  if (temps.length) out.push({label: METRICS.temperature[0], sub: temps[0][0], value: temps[0][1], unit: '°C', limits: LIMITS.temperature,
    detail: `Hottest of ${temps.length} ${temps.length === 1 ? 'sensor' : 'sensors'}`, tab: 'thermal', name: temps[0][0]});
  return out;
}
const hottest = s => Object.entries(s.temperature).filter(([, value]) => Number.isFinite(value)).sort((a, b) => b[1] - a[1]);

// Readings at their warning level or worse, critical first, with the view that shows each (the link, the tab's dot)
function alertsOf(s) {
  const alerts = [];
  for (const r of readings(s)) {
    const lv = r.value == null ? 'ok' : level(r.value, r.limits);
    if (lv !== 'ok') alerts.push({lv, tab: r.tab, name: r.name || r.label, value: r.value.toFixed(1) + ' ' + r.unit});
  }
  for (const [name, value] of hottest(s).slice(1)) {  // every hot sensor, not only the hottest
    const lv = level(value, LIMITS.temperature);
    if (lv !== 'ok') alerts.push({lv, tab: 'thermal', name, value: value.toFixed(1) + ' °C'});
  }
  // other filesystems, from the storage observation when the Storage view fetched it; the root card covers /
  const storage = obs && obs.groups && obs.groups.storage;
  const fsData = storage && storage.observation && !observationStale(storage) ? storage.data : null;
  for (const f of listOf(fsData, 'filesystems')) {
    const lv = f.total_bytes && !f.mount_points.some(p => p.path === '/') ? level(fsPct(f), LIMITS.filesystem) : 'ok';
    if (lv !== 'ok') alerts.push({lv, tab: 'storage', name: f.mount_points[0].path, value: fsPct(f).toFixed(0) + ' %'});
  }
  // the batteries' charge and connected Wi-Fi signals, when their views fetched a current observation
  const current = name => { const g = obs && obs.groups && obs.groups[name]; return g && g.observation && !observationStale(g) ? g.data : null; };
  for (const b of listOf(current('battery'), 'batteries')) {
    const lv = b.present !== false && Number.isFinite(b.percent) ? levelOf('battery', b.percent) : 'ok';
    if (lv !== 'ok') alerts.push({lv, tab: 'power', name: b.name, value: b.percent + ' %'});
  }
  for (const i of listOf(current('wifi'), 'interfaces')) {
    const lv = i.connected === true && Number.isFinite(i.signal_dbm) ? levelOf('wifi', i.signal_dbm) : 'ok';
    if (lv !== 'ok') alerts.push({lv, tab: 'network', name: i.name, value: i.signal_dbm + ' dBm'});
  }
  return alerts.sort((a, b) => (b.lv === 'crit') - (a.lv === 'crit'));
}
const pills = alerts => alerts.map(a =>
  `<a class="pill ${a.lv}" href="#${a.tab}">${esc(a.name)} <span class="mono">${esc(a.value)}</span></a>`).join('');
// The Needs attention card of the status slot (empty when nothing needs attention)
const attentionHtml = s => { const alerts = alertsOf(s); return alerts.length ? '<strong>Needs attention</strong>' + pills(alerts) : ''; };

// recent rx + tx of each interface, about 10 answers, so two interfaces with similar traffic do not swap places every second
const traffic = {};
function remember(s) {
  for (const i of listOf(s.network, 'interfaces')) if (i.rates) {
    const seen = traffic[i.name] ||= [];
    seen.push(i.rates.rx_bytes_per_s + i.rates.tx_bytes_per_s);
    if (seen.length > 10) seen.shift();
  }
}
const busy = i => !i.rates ? -1 : traffic[i.name] && traffic[i.name].length
  ? traffic[i.name].reduce((a, v) => a + v, 0) / traffic[i.name].length : i.rates.rx_bytes_per_s + i.rates.tx_bytes_per_s;

function overviewRows(s) {
  const cards = readings(s).map(r => {
    const lv = r.value == null ? 'ok' : level(r.value, r.limits);
    return `<article class="card metric"><div class="metric-head"><span>${esc(r.label)}</span><span>${esc(r.sub)}</span></div>` +
      (r.value == null ? '<div class="value">Unavailable</div>'
        : `<div class="value${textLevel(lv)}">${r.value.toFixed(1)}<span class="unit">${r.unit}</span></div>${bar(r.value, r.limits)}`) +
      // the CPU detail is built from escaped parts (it colors the busiest core); the others are plain text
      (r.detail ? `<div class="detail">${r.label === METRICS.cpu[0] ? r.detail : esc(r.detail)}</div>` : '') + '</article>';
  });
  let html = `<div class="metrics">${cards.join('')}</div>`;
  // Show individual readings: names and traffic volume do not identify the host's uplink.
  const interfaces = listOf(s.network, 'interfaces').filter(i => i.name !== 'lo').sort((a, b) => busy(b) - busy(a));
  if (interfaces.length) {
    const shown = interfaces.slice(0, 4);
    html += '<section class="card"><div class="card-head"><h2>Network</h2><a class="cap" href="#network">All interfaces →</a></div>' +
      table('minmax(0, 1fr) 110px 110px', ['Interface', COLUMNS.rx[0], COLUMNS.tx[0]], shown.map(i => tr([esc(i.name),
        i.rates ? perS(i.rates.rx_bytes_per_s) : why(i), i.rates ? muted(perS(i.rates.tx_bytes_per_s)) : ''], idle(i.rates)))) +
      (shown.length < interfaces.length ? `<p class="note">Showing ${shown.length} of ${interfaces.length}</p>` : '') + '</section>';
  }
  return html;
}
function renderResources(s) {
  const note = cpuNote(s), cpus = s.cpu.filter(c => Number.isFinite(c.usage));
  const unavailable = (s.cpu_sampling && s.cpu_sampling.unavailable || []).length;
  // every core at one clock: said once in the caption rather than under each of them
  const clocks = new Set(s.cpu.map(c => c.freq)), same = clocks.size === 1 && !!s.cpu[0].freq;
  $('cpu-cap').textContent = cpus.length ? `mean ${(cpus.reduce((sum, c) => sum + c.usage, 0) / cpus.length).toFixed(1)} % · ` +
    `${cpus.length} of ${s.cpu.length + unavailable} measured` + (same ? ` · all at ${mhz(s.cpu[0].freq)}` : '') : '';
  $('cpu').innerHTML = (s.cpu.length ? '<div class="cores">' + s.cpu.map(c => `<div class="core"><span>CPU${c.id}</span>` +
    `<strong class="${textLevel(level(c.usage, LIMITS.cpu))}">${c.usage.toFixed(1)} %</strong>` +
    bar(c.usage, LIMITS.cpu, false) + (same ? '' : `<span>${mhz(c.freq) || '&nbsp;'}</span>`) + '</div>').join('') + '</div>' : '') +
    (note ? `<div class="muted">${esc(note)}</div>` : '');
  const m = s.memory, g = s.gpu, n = s.npu;
  // the NPU has no levels in [thresholds], so its bar carries none either
  const load = (a, label) => meter(label, (a.usage == null ? 'no load reading' : a.usage.toFixed(1) + ' %') +
    (a.freq ? ' · ' + (a.max_freq ? `${(a.freq / 1e6).toFixed(0)} / ${mhz(a.max_freq)}` : mhz(a.freq)) : ''),
    a.usage == null ? 0 : a.usage, label === 'GPU' ? LIMITS.gpu : null);
  $('res').innerHTML = '<div class="meters">' +
    (g ? load(g, 'GPU') : '') + (n ? load(n, 'NPU') : '') +
    meter('RAM', `${size(m.used)} / ${size(m.total)}`, pctOf(m.used, m.total), LIMITS.memory) +
    (m.swap_total ? meter('Swap', `${size(m.swap_used)} / ${size(m.swap_total)}`, pctOf(m.swap_used, m.swap_total), LIMITS.memory) : '') + '</div>';
  $('psi').innerHTML = psiRows(s);
}
// in the server's order, as the history below and the terminal: a sensor keeps its line as temperatures cross
function renderThermal(s) {
  const temps = Object.entries(s.temperature).filter(([, v]) => Number.isFinite(v));
  $('temp-cap').textContent = `Bar scale 0–100 °C · warning ${LIMITS.temperature[0]} · critical ${LIMITS.temperature[1]}`;
  $('temp').innerHTML = temps.length ? '<div class="temps">' + temps.map(([k, v]) =>
    `<div class="temp"><span>${esc(k)}</span>${bar(v, LIMITS.temperature)}<span>${v.toFixed(1)} °C</span></div>`).join('') + '</div>' : '';
}
// what the board draws and what it has left, read together: consumption is the draw over a window
// against the charge that window cost
function renderPower(s) {
  const rails = Object.entries(s.power);
  // the last line in bold is the total, as a power meter reads; one rail is its own total
  const sum = rails.length > 1 ? `<div class="kv sum"><span>Sum of rails</span><span><b>${rails.reduce((a, [, v]) => a + v, 0).toFixed(2)} W</b></span></div>` : '';
  // a fan with a duty gets its bar (grey: a duty has no level), its speed beside it
  const fan = f => f.percent !== null ? meter('Fan ' + esc(f.name), [f.rpm !== null && f.rpm + ' rpm', f.percent + ' %'].filter(Boolean).join(' · '), f.percent, null)
    : kv('Fan ' + esc(f.name), f.rpm !== null ? f.rpm + ' rpm' : 'n/a');
  const rows = rails.map(([k, v]) => kv(esc(k), v.toFixed(2) + ' W')).join('') + sum + s.fans.map(fan).join('');
  $('pwr-cap').innerHTML = s.power_mode ? `<span class="chip">MODE ${esc(s.power_mode)}</span>` : '';
  $('pwr').innerHTML = rows || (s.power_mode ? '<p class="muted">No power rails or fans reported.</p>' : '');
}
function renderSystem(s) {
  const sys = s.system || {};
  const fields = {model: s.model, platform: s.platform, uptime: uptimeText(s.uptime)};
  for (const key of SYSTEM_FIELDS) fields[key] = sys[key];
  for (const [key, value] of Object.entries(fields)) {
    const text = value == null ? '' : String(value);
    if ($('system-' + key).textContent !== text) $('system-' + key).textContent = text;
    $('system-' + key + '-row').hidden = !text;
  }
  // Preserve additional board-specific fields without changing the API or rebuilding stable rows.
  const extra = Object.entries(sys).filter(([key, value]) => !SYSTEM_FIELDS.includes(key) && value)
    .map(([key, value]) => `<div class="sys"><span>${esc(key)}</span><span>${esc(value)}</span></div>`).join('');
  if ($('system-extra').innerHTML !== extra) $('system-extra').innerHTML = extra;
  // this page's own: the service it reads (the version is filled in by the server)
  const service = `${location.host || 'this page'} · every 1 s`;
  if ($('system-service').textContent !== service) $('system-service').textContent = service;
}
function renderActive() {
  if (!latestStats || !visible()) return;
  const s = latestStats;
  if (activeTab === 'overview') {  // rebuilt every second: keyboard focus stays on the same link
    const links = () => [...document.querySelectorAll('#overview a')], at = links().indexOf(document.activeElement);
    $('overview').innerHTML = overviewRows(s);
    if (at >= 0 && links()[at]) links()[at].focus();
  }
  else if (activeTab === 'resources') renderResources(s);
  else if (activeTab === 'network') { $('net').innerHTML = netRows(s); $('net-cap').textContent = netCaption(s); }
  else if (activeTab === 'storage') $('dio').innerHTML = diskRows(s);
  else if (activeTab === 'thermal') renderThermal(s);
  else if (activeTab === 'power') renderPower(s);
  else if (activeTab === 'system') renderSystem(s);
  hideEmptyPanels();
}
function renderObservations() {
  if (!visible()) return;
  if (activeTab === 'storage') $('sto').innerHTML = storageRows();
  if (activeTab === 'network') { $('wifi').innerHTML = wifiRows(); $('probe').innerHTML = probeRows(); }
  if (activeTab === 'power') $('batt').innerHTML = batteryRows();
  hideEmptyPanels();
  updateDetailAges();
}
function render(s) {
  // Keep the last good snapshot for instant view switches even if the next request fails.
  // A phone has no room for the model: it gets the host's name and the platform, as the terminal does below 100 columns.
  const sys = s.system || {}, up = Number.isFinite(s.uptime) ? 'up ' + uptimeText(s.uptime) : '';
  const both = (wide, narrow) => wide === narrow ? esc(wide) : `<span class="wide">${esc(wide)}</span><span class="narrow">${esc(narrow)}</span>`;
  $('model').innerHTML = both(s.model, sys.hostname || s.model);
  $('subtitle').innerHTML = both([sys.hostname, s.power_mode, up].filter(Boolean).join(' · '),
    [s.platform, s.power_mode, up].filter(Boolean).join(' · '));
  $('coll').textContent = collectionNote(s);
  latestStats = s;
  remember(s);
  renderActive();
  renderSlot();
}
// The status slot, every view: a lost service, else a partial collection with the warnings in its banner, else the
// warnings' card, else an empty slot of the same height; and each view's tab marked with its worst warning.
function renderSlot() {
  const alerts = latestStats ? alertsOf(latestStats) : [], coll = $('coll').textContent;
  $('err-banner').hidden = !failing;
  $('coll-banner').hidden = failing || !coll;
  $('coll-attention').innerHTML = !failing && coll ? pills(alerts) : '';
  $('attention').innerHTML = !failing && !coll && latestStats ? attentionHtml(latestStats) : '';
  $('attention').hidden = !$('attention').innerHTML;
  for (const tab of TABS) $('tab-' + tab).setAttribute('data-attention', (alerts.find(a => a.tab === tab) || {}).lv || '');
}
function updateDetailAges() {
  document.querySelectorAll('#panel-' + activeTab + ' [data-observation-age]').forEach(el => {
    el.textContent = observationAge(el.dataset.observationAge);
  });
  if (!$('history-panel').hidden) document.querySelectorAll('[data-history-age]').forEach(el => {
    el.textContent = historyAge(Number(el.dataset.historyAge));
  });
}

const TIMEOUT_MS = 5000;  // a request that hangs must not stop the updates
// What is on screen and how old it is. The age comes from the server (data_age_ms) plus browser time since
// that answer arrived (performance.now, so the device and browser clocks never get compared); it ignores
// transfer time. A repeated 200 for the same sample keeps counting from the server's age, never from 0.
// Older servers send no sample metadata: then only the time since their last answer is known.
let shown = null;       // {kind: 'sample' | 'legacy' | 'invalid', seq, ageMs, t0}
let failing = false;    // the last request failed: what is shown is the last good data, not current
let checking = false;   // tab came back: browser time may have stopped while hidden, wait for a new answer
let inflight = null, refresh = null;  // inflight: the running request's AbortController
let epoch = 0;          // counts tab returns: an answer to a request started before the latest one proves nothing

function sampleOf(s, t0) {
  if (!('schema_version' in s) && !('sample' in s)) return {kind: 'legacy', t0};
  const m = s.sample;
  const ok = s.schema_version === 1 && m && typeof m === 'object' && typeof m.instance_id === 'string'
    && Number.isInteger(m.sequence) && m.sequence > 0 && Number.isFinite(m.data_age_ms) && m.data_age_ms >= 0;
  return ok ? {kind: 'sample', seq: m.sequence, ageMs: m.data_age_ms, t0} : {kind: 'invalid', t0};
}

// The status pill says Live, Partial or Offline; its tooltip carries the sample number and data age.
// Offline shows a banner with the error and the last good data's age, and dims the views.
function showAge() {
  const coll = $('coll').textContent;
  const [status, state] = failing ? ['Offline', 'offline'] : checking ? ['Checking', 'idle'] : !shown ? ['Connecting', 'idle']
    : coll ? ['Partial', 'partial'] : ['Live', 'live'];
  if ($('status').textContent !== status) $('status').textContent = status;
  $('status').setAttribute('data-state', state);
  $('main').setAttribute('data-offline', String(failing));
  renderSlot();
  $('stale').hidden = true;
  if (!shown) { $('status').title = $('err-age').textContent = ''; return; }
  const since = performance.now() - shown.t0;
  const secs = ms => Math.round(ms / 1000) + ' s';
  // the age beside the status only when it says something: older than two updates (offline: the banner says it)
  const age = shown.kind === 'sample' ? shown.ageMs + since : since;
  if (!failing && !checking && age > 2000) { $('stale').textContent = `data ${secs(age)} old`; $('stale').hidden = false; }
  const text = shown.kind === 'sample' ? `sample #${shown.seq} · data age ${secs(shown.ageMs + since)}`
    : `response received ${secs(since)} ago · ` + (shown.kind === 'legacy'
      ? 'this server reports no sample age' : 'sample age unavailable (invalid metadata)');
  const line = failing ? 'last good: ' + text + ' (not current)' : checking ? 'checking… last seen: ' + text : text;
  $('status').title = line[0].toUpperCase() + line.slice(1);
  $('err-age').textContent = failing ? (shown.kind === 'sample' ? ` Showing the last good sample, ${secs(shown.ageMs + since)} old.`
    : ` Showing the last good answer, received ${secs(since)} ago.`) : '';
}

// One request at a time; whatever happens, the next one is scheduled. On failure the last good values
// stay on screen with their age, and the message says what failed.
async function tick() {
  if (inflight || !visible()) return;
  clearTimeout(refresh);
  const ctl = inflight = new AbortController(), mine = epoch;
  const timer = setTimeout(() => ctl.abort(), TIMEOUT_MS);
  let stage = 'connect';
  try {
    const r = await fetch('api/stats', {signal: ctl.signal, cache: 'no-store'});
    if (r.status === 503) throw new Error('No current data: platmon is running but has no recent sample (see its log)');
    if (!r.ok) throw new Error(`platmon answered ${r.status} ${r.statusText}`);
    stage = 'read';
    const s = await r.json();
    const t0 = performance.now();
    if (mine !== epoch) return;  // started before the tab came back: drop it, finally asks again
    stage = 'render';
    render(s);
    shown = sampleOf(s, t0);
    failing = checking = false;
    $('err').textContent = '';
  } catch (e) {
    if (mine !== epoch) return;
    failing = true;  // shown keeps its own age: a failure does not make old data newer
    checking = false;
    $('err').textContent = e.name === 'AbortError' ? `No answer within ${TIMEOUT_MS / 1000} s`
      : stage === 'connect' && e instanceof TypeError ? 'Connection lost: ' + e.message
      : stage === 'read' ? 'Unexpected response (not platmon data)'
      : e.message;
  } finally {
    clearTimeout(timer);
    inflight = null;
    refresh = visible() ? setTimeout(tick, mine === epoch ? 1000 : 0) : null;
    if (visible()) showAge();
  }
}
setInterval(() => {
  if (!visible()) return;
  showAge(); pollObs(); pollHist();
  updateDetailAges();
}, 1000);  // ages keep moving while a request hangs
for (const [index, tab] of TABS.entries()) {
  $('tab-' + tab).addEventListener('click', () => activateTab(tab));
  $('tab-' + tab).addEventListener('blur', event => {
    if (TABS.some(name => $('tab-' + name) === event.relatedTarget)) return;
    // Re-entering the tab list returns to the selected view, even after arrow-only exploration.
    for (const name of TABS) $('tab-' + name).tabIndex = name === activeTab ? 0 : -1;
  });
  $('tab-' + tab).addEventListener('keydown', event => {
    const next = event.key === 'ArrowRight' ? (index + 1) % TABS.length : event.key === 'ArrowLeft' ? (index + TABS.length - 1) % TABS.length
      : event.key === 'Home' ? 0 : event.key === 'End' ? TABS.length - 1 : null;
    if (next === null) return;
    event.preventDefault();
    // Manual activation: moving focus never sends a request; Enter/Space click the native button.
    for (const name of TABS) $('tab-' + name).tabIndex = name === TABS[next] ? 0 : -1;
    $('tab-' + TABS[next]).focus();
  });
}
$('history-groups').addEventListener('click', event => {
  const button = event.target.closest && event.target.closest('[data-group]');
  if (!button) return;
  if (!histOff.delete(button.dataset.group)) histOff.add(button.dataset.group);  // delete reports a hit
  histDraw();
});
$('hist').addEventListener('click', event => {
  if (!event.target.closest || !event.target.closest('[data-cores]')) return;
  histCoresOpen = !histCoresOpen;
  histDraw();
});
$('hist').addEventListener('pointermove', readout);
$('hist').addEventListener('pointerleave', readout);
document.addEventListener('visibilitychange', () => {
  epoch++;
  clearTimeout(refresh); refresh = null;
  if (obsRequest) obsRequest.abort();
  if (histRequest) histRequest.abort();
  if (!visible()) { if (inflight) inflight.abort(); return; }
  obs = hist = null;
  obsAsked = histAsked = -Infinity;
  for (const id of ['sto', 'wifi', 'probe', 'hist']) $(id).innerHTML = '';
  hideEmptyPanels();
  $('history-panel').hidden = true;
  checking = true;
  showAge();
  if (inflight) inflight.abort();  // its answer would not count; its finally starts the new request
  else tick();
});
const restoreTab = () => activateTab(TABS.includes(location.hash.slice(1)) ? location.hash.slice(1) : 'overview', false);
window.addEventListener('hashchange', restoreTab);
restoreTab();
tick();
